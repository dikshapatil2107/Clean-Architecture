package com.example.cleanarchitecturenoteapp.features_notes.domain.util


sealed class OrderType {
    object Ascending: OrderType()
    object Descending: OrderType()
}